#include<stdio.h>
int main()
{
	int i,j,n,r,c,sum=0;
	printf("Enter the number of rows:");
	scanf("%d",&r);
	printf("Enter the number of column:");
	scanf("%d",&c);
	int a[r][c];
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
		scanf("%d",&a[i][j]);
	    }
	}
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			if(i==j)
			{
			    sum=sum+a[i][j];
			}
		}
	}
	printf("The sum of the digonal of the given array is :%d",sum);
}
