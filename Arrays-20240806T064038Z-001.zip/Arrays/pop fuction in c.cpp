#include<stdio.h>
int main()
{
	int n,i,j,r;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
	   scanf("%d",&a[i]);
	}
	printf("Enter the position of the number to delet:");
	scanf("%d",&r);
	for(i=0;i<n;i++)
	{
		if(r==i)
		{ 
			continue;
		}
		else
		{
			printf("%d,",a[i]);
		}
	}
}
