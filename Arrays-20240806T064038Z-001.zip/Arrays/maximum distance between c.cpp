#include<stdio.h>
int main()
{
	int i,j,n,count=0,c=0,max;
	scanf("%d",n);
	int a[n];
    for(i=0;i<n;i++)
    {
    	scanf("%d",&a[i])
	}
	
	for(i=0;i<n;i++)
	{
		count=0;
		max=0;
		for(j=i+1;j<n;j++)
		{
			count++;
			if(a[i]==a[j])
			{
				max=count;
			}
			if(max>c)
			{
				c=max;
			}
		}
	}
	printf("%d",c);
}
