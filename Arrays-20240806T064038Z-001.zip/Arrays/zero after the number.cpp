#include<stdio.h>
int main()
{
	int n,i,j,count=0,k=0;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
    {
    	scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		if(a[i]==0)
		{
			count++;
		}
	}
	for(i=0;i<n;i++)
	{
		if(a[i]==0)
		{
			if(count!=0)
			{
				printf("%d",k);
				count--;
			}
		}
		else
		{
			printf("%d",a[i]);
			if(count!=0)
			{
				printf("%d",k);
				count--;
			}
		}
	}
}
