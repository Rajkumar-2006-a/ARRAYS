#include<stdio.h>
int main()
{
	int n,count=0;
	printf("Enter the size of the array:");
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++)
	{
		printf("Enter the elements of the array:");
		scanf("%d",&a[i]);
	}
	for(int r=0;r<n;r++)
	{
		for(int j=r+1;j<n;j++)
		{
			if(a[r]==a[j])
			{
				printf("The duplicate elements are:%d\n",a[r]);
				count++;
			}
		}
	}
	if(count==0)
	{
		printf("No duplicate elements");
	}
	printf("The number of duplicate elemnts:%d\n",count);
}
