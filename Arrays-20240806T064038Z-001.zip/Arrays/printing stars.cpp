#include<stdio.h>
int main()
{
	int n,n1,i,j;
	scanf("%d",&n);
	scanf("%d",&n1);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n1;j++)
		{
			printf("*");
			if(i%2==0)
			{
				printf("*");
			}
		}
		printf("\n");
	}
}
