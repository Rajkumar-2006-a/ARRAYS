#include<stdio.h>
int main()
{
    int i , j , n,min=0;
    printf("enter the no of elements : ");
    scanf("%d",&n);
    int a[n],final[n];
    for(i= 0 ; i<n ; i++)
    {
        scanf("%d",&a[i]);
    }
    int man=a[0];
    for(i=0;i<n;i++)
    {
	  for(j=0;j<n;j++)
	  {
	  	if(a[j]>max)
	  	{
	  		max=a[j];
		}
	  }
	  final[i]=min;
	  min=0;
	}
	for(i=0;i<n;i++)
	{
		printf("%d",final[i]);
	}
}
