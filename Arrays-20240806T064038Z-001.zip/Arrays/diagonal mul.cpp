#include<stdio.h>
int main()
{
	int i,j,r,c;
	printf("Enter the number of rows:");
	scanf("%d",&r);
	printf("Enter the number of column:");
	scanf("%d",&c);
	int a1[r][c],a2[r][c],final[r];
	printf("Enter the matrix 1:");
		for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			scanf("%d",&a1[i][j]);
		}
	}
	printf("Enter the matrix 2:");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			scanf("%d",&a2[i][j]);
		}
	}

	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			if(i==j)
			{
			final[i]=a1[i][j]*a2[i][j];
	        }
		}
	}
	for(i=0;i<r;i++)
	{
		printf("%d ",final[i]);
	}
}
