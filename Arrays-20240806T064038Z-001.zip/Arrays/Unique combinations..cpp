#include<stdio.h>
int main()
{
    int i , j , n , k ,target ; 
    printf("Enter the no of elements : ");
    scanf("%d",&n);
    int a[n] , b=-1,  c=-1, d=-1;
    printf("\nEnter the target element");
    scanf("%d",&target);
    for(i=0 ; i<n ; i++)
    {
            scanf("%d",&a[i]);
    }
    
    for(i=0 ; i<n ; i++)
    {
        for(j=i+1 ; j<n ; j++)
        {
            for(k=i+2 ; k<n ; k++)
            {
                if(a[i]+a[j]+a[k] == target )
                {
                    if(a[i] != b && a[j] != c && a[k] != d)
                    {
                        printf("%d %d %d\n",(i+1),(j+1),(k+1));
                        b = a[i] ; 
                        c= a[j];
                        d = a[k];
                    }
                    else
                    {
                        continue;
                    }
                }
                    
                }
                if(a[i]+a[j]==target)
                {
                    printf("%d %d\n",(i),(j));
                }
                else
                {
                    continue;
                }
                
            }
        }
    }
