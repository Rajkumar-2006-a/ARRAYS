#include<stdio.h>

int main()
{
 int n1,n2,n3,i,j,r=0,temp;
 printf("Enter the number of elements for array 1:");
 scanf("%d",&n1);
 
 printf("Enter the number of elements for array 2:");
 scanf("%d",&n2);
  n3=n1+n2;
int a[n1],b[n2],c[n3];

 printf("Enter the elements for array 1:");
 for(i=0;i<n1;i++)
 {
 	scanf("%d",&a[i]);
 }
 
 printf("Enter the elements for array 2:");
 
 for(i=0;i<n2;i++)
 {
 	scanf("%d",&b[i]);
 }
printf("The merged array is:");
for(i=0;i<n1;i++)
{
	c[i]=a[i];
}

for(i=0;i<n2;i++)
{
	c[i+n1]=b[i];
}

for(i=0;i<n3;i++)
{
	for(j=i+1;j<n3;j++)
	{
		if(c[i]>c[j])
		{
			temp=c[j];
			c[j]=c[i];
			c[i]=temp;
		}
	}
}
   for(i=0 ; i<n3; i++)
    {
        printf("%d ",c[i]);
    }
}
