#include<stdio.h>
int main()
{
	int i,j,n;
	scanf("%d",&n);
	int mat[n];
	for(i=0;i<n;i++)
		{
			scanf("%d",&mat[i]);
		}
    int max=mat[0];
    for(i=0;i<n;i++)
    {
	  for(j=i+1;j<n;j++)
	  {
	  	if(mat[j]>max)
	  	{
	  		max=mat[j];
		}
	  }
    }
	printf("The sum is:%d",max);

}
