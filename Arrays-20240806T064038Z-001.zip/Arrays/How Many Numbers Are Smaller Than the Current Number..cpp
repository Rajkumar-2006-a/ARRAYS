#include<stdio.h>
int main()
{
	int n,i,j,count,r;
	printf("Enter the number of elements in the array:");
	scanf("%d",&n);
	int a[n],res[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
    }
	 
	for(i=0;i<n;i++)
	{
	  if(a[i]!=0)
	  {
		printf("%d ",a[i]);
	  }
	  if(a[i]==0)
	  {
	  	count++;
	  }

	  
	}
	
	for(i=0;i<n;i++)
	{
		printf("%d",res[i]);
	}

}

