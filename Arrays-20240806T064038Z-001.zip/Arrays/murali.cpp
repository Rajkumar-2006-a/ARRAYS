#include<stdio.h>
int main(){
	int a,i,j,count=0,max,c=0;
	printf("enter the size of the array:");
	scanf("%d",&a);
	int b[a];
	for(i=0;i<a;i++)
	{
		scanf("%d",&b[i]);
	}
    for(i=0;i<a;i++)
    {
        c=0;
        for(j=0;j<a;j++)
        {
            if(b[i]>b[j])
            {
                c++;
            }
        }
        printf("%d ",c);
    }
    
}
