#include<stdio.h>
int main()
{
    int n,count=0,i;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(a[i]==a[j])
            {
            count++;
            printf("The duplicate elemnts are:%d",a[i]);
            }
        }
    }
    printf("%d",count);
}
