#include<stdio.h>
int main()
{
    int i , j , n ,max=1,min=1,m,c=0;
    printf("enter the no of elements : ");
    scanf("%d\n",&n);
    int a[n];
    for(i= 0 ; i<n ; i++)
    {
        scanf("%d",&a[i]);\
    }
    printf("Enter the target element in the array:");
    scanf("%d",&m);
    for(i=0;i<n;i++)
    {
    	for(j=i+1;j<n;j++)
    	{
    		if(a[i]+a[j]==m)
    		{
    			printf("THe index is %d and %d\n",i,j);
    			printf("The values are %d and %d\n",a[i],a[j]);
    			c++;
			}
		}
		if(c==1)
		{
			break;
		}
	}
    
}
	
