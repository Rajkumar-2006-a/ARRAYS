#include<stdio.h>
int main()
{
	int i,j,n;
	printf("Enter the number of elements:");
	scanf("%d",&n);
	int a[n],final[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		final[i]=1;
		for(j=0;j<n;j++)
		{
			if(i==j)
			{
				continue;
			}
			else
			{
			final[i]=final[i]*a[j];
		    }
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",final[i]);
	}
}
