#include<stdio.h>
int main()
{
    int i , j , n,min;
    printf("enter the no of elements : ");
    scanf("%d",&n);
    int a[n];
    for(i= 0 ; i<n ; i++)
    {
        scanf("%d",&a[i]);
    }
    min=a[0];
    for(i=0;i<n;i++)
    {
	  for(j=i+1;j<n;j++)
	  {
	  	if(a[i]>a[j])
	  	{
	  		min++;
		}
	  }
	}
	printf("\nThe minimum element in the array is:%d ",min);
}
