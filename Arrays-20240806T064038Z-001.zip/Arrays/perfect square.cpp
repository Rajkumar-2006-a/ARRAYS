#include<stdio.h>
int main()
{
	float i,n;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		if(i*i==n)
		{
			printf("The number is perfect square");
		}
	}
	printf("Not raj");
}
