#include<stdio.h>
int main()
{
	int n,i,j,r,c,status=0;
	printf("Enter the number of rows:");
	scanf("%d",&r);
	printf("Enter the number of column:");
	scanf("%d",&c);
	int mat[r][c];
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			scanf("%d",&mat[i][j]);
		}
	}
	if(r==c)
	{
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			if(mat[i][j]!=mat[j][i])  
			{
				status=1;
			}
		}
	}
    }
    else
    {
     printf("not symmetric");
    }
	if(status==0)
	{
		printf("Symmetric");
	}
	else
	{
		printf("Not symmetric");
	}
	
}
