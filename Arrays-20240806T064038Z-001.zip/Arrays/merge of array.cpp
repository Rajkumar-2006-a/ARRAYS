#include<stdio.h>
int main()
{
    int i , j , n1 , n2,temp;
    printf("Enter no of the elements of first array");
    scanf("%d",&n1);
    printf("\nEnter no of the elements of second array");
    scanf("%d",&n2);
    int a[n1],b[n2],c[n1+n2];
    printf("\nfirst array:");
    for(i=0 ; i<n1 ; i++)
    {
        scanf("%d",&a[i]);
    }
    printf("\nsecond array:");
    for(i=0 ; i<n2 ; i++)
    {
        scanf("%d",&b[i]);
    }
   for(i=0 ; i<n1 ; i++)
   {
       c[i] = a[i];
   }
   for(i=0 ; i<n2 ; i++)
   {
       c[i+n1] = b[i];
   }
   int n3=n1+n2;
   	for(i=0;i<n3;i++)
	{
		for(j=i+1;j<n3;j++)
		{
			if(c[i]>c[j])
			{
				temp=c[i];
				c[i]=c[j];
				c[j]=temp;
			}
		}
	}
   printf("\nThird array :");
    for(i=0 ; i<n3; i++)
    {
        printf("%d ",c[i]);
    }
}
