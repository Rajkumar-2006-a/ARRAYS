#include<stdio.h>
int main()
{
	printf("Enter the string:");
	scanf("%[^\n]s",&a);
	char a[];
    int r=strlen(a);
    for(i=0;i<n;i++)
    {
    	printf("%s\n",a[i]);
	}
}
