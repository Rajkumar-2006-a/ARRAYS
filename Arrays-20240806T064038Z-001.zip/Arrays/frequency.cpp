#include<stdio.h>
int main()
{
	int n,c;
	scanf("%d",&n);
	printf("Enter the elements:");
	int a[n],b[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n;i++)
	{
		c=1;
		if(a[i]!=0)
		{
		for(int j=i+1;j<n;j++)
		{
			if(a[i]==a[j])
			
			{
			c++;
			a[j]=0;
		    }
		}
		b[i]=c;
	    }
	}
	for(int i=0;i<n;i++)
	{
		if(a[i]!=0)
		{
			printf("%d occurs %d\n",a[i],b[i]);
		}
	}
}
