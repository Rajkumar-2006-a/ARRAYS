#include<stdio.h>
int main()
{
	int n,i,j,temp,r,f;
	printf("Enter the number of array elements:");
	scanf("%d",&n);
	int a[i];
	printf("Enter the elements:");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		while(i<n)
		{
			f=a[i]/10;
			r=a[i]%10;
			printf("%d,%d,",f,r);
			i++;
		}
	}
}
