#include<stdio.h>
int main()
{
    int i , j , n ;
    printf("enter the no of elements : ");
    scanf("%d",&n);
    int a[n];
    for(i= 0 ; i<n ; i++)
    {
        scanf("%d",&a[i]);
    }
    int rotate;
    scanf("%d",&rotate);
    printf("\n enter the rotate element");
    for(i=rotate ; i<n ; i++)
    {
        printf("%d",a[i]);
    }
     for(i=0 ; i<rotate ; i++)
    {
        printf("%d",a[i]);
    }
}
