#include<stdio.h>
int main(){
    int choice;
    printf("Ithu ungal kunju kumar@(raj kumar) swamigal from panruti meliruppu(allathu)keelirupu\n");
    printf("CHOICE:\n");
    printf("1.Personal dharisanam\n");
    printf("2.Foursome dharisanam\n");
    printf("3.Foreign dharisanam\n");
    printf("4.Video call dharisanam\n");
    printf("enter the choice(1/2/3/4):");
    scanf("%d",&choice);
    switch(choice){
        case 1:
        printf("Come to room n0:283 at midnight,i will give my full body for dharisanam...\n");
        break;
        case 2:
        printf("Come to room no:283 with (nandh and priyan) i will gave a foursome dharisanam...\n");
        break;
        case 3:
        printf("Come to panrutiyaash island for foreign dharisanam...\n");
        break;
        case 4:
        printf("Put video call for this no: 63805 32229 .I will show my full body on video call for your wonderfull dharisanm.....\n");
        break;
        default:
        printf("invalid choice ,u lost the wonderfull kunju swamigal dharisanam..\n");
        break;
    }
    printf("Thanks for visiting (KUNJU SWAMIGAL!!!) and there is kunju swamigal birthday is today.grab your offer soon...!!! \ngmail:rajkumara.cs23@bitsathy.ac.in\n");
    printf("!.........hara hara kunju devakiiii.........!");
    
}
