#include <stdio.h>

int main()
{
    int no;
    int count;
    
    printf("Enter no of elements in the array : ");
    scanf("%d",&no);
    
    int arr[no];
    
    printf("Enter the elements :\n");
    for (int i=0; i<no; i++)
    {
        scanf("%d",&arr[i]);
    }
    
    printf("\nGiven Array: ");
    for (int i=0; i<no; i++)
    {
        printf("%d ",arr[i]);
    }
    
    for (int i=0; i<no; i++)
    {
        for (int k=i+1; k<no; k++)
        {
            if (arr[i]==arr[k])
            {
                count++;
                for(int j=k; j<no-1; j++)
                {
                    arr[j]=arr[j+1];
                }
                no--;
                k--;
            }
        }
    }
    printf("\nNumber of duplicate elements : %d\n",count);
    
    for (int i=0; i<no; i++)
    {
        printf("%d ",arr[i]);
    }
}

