#include<stdio.h>
int main()
{
	int n,i,j,r,c,k;
	printf("Enter the number of rows:");
	scanf("%d",r);
	printf("Enter the number of column:");
	scanf("%d",c);
	int a[r][c],b[r][c],mul[r][c];
	printf("Enter the elemnts for matrix 1:");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	printf("Enter the elemnts for matrix 2:");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			scanf("%d",&b[i][j]);
		}
	}
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			for(k=0;k<r;k++)
			{
				mul[i][j]=a[i][k]*b[k][j];
			}
		}
	}
		for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			printf("%d",mul[i][j]);
		}
	}
}
