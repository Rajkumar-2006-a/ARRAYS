#include<stdio.h>
int main()
{
	int i,n,j;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int r=sizeof(a)/sizeof(a[0]);
	int temp=a[0];
	a[0]=a[r-1];
	a[r-1]=temp;
	for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
}
