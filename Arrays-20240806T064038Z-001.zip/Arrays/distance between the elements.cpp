#include<stdio.h>
int main()
{
    int a, count=0;
    printf("Input the number of elements to store in array : ");
    scanf("%d", &a);
    printf("Input %d number of elements are stored in array", a);
    printf("\n");
    int arr[a];
    for(int i=0;i<a;i++)
    {
        scanf("%d", &arr[i]);
    }
    
    for(int i=0;i<a;i++)
    {
        for(int j=i+1;j<a;j++)
        {
            if(arr[i] != arr[j])
            {
                count++;
            }
        }
        break;
    }
    printf("%d ", count);
}
